# Detailed theory extensions

To są wersje notebooków z dokładniejszymi opisami teoretycznymi w Markdown, w stylu wcześniejszych materiałów wykładowych.

W porównaniu z poprzednią paczką dodano szczególnie w notebookach algorytmicznych:
- ręczne przykłady liczbowe,
- dokładniejsze definicje i wzory,
- tabele interpretacyjne,
- sekcje z typowymi pułapkami,
- komentarze dydaktyczne: jak czytać eksperyment i wyniki.

Kod pozostał logicznie bez zmian; rozszerzenia dotyczą objaśnień i prowadzenia narracji.
